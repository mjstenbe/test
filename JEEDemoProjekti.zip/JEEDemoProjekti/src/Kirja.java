



public class Kirja {

	private String teoksenNimi;
	private int julkaisuvuosi;
	private String tekija;

	public Kirja() {
		this.teoksenNimi = "ei m��ritelty";
		this.julkaisuvuosi = 0;
		this.tekija = "tuntematon";
	}

	public Kirja(String teoksenNimi, int julkaisuvuosi, String tekija) {
		super();
		this.teoksenNimi = teoksenNimi;
		this.julkaisuvuosi = julkaisuvuosi;
		this.tekija = tekija;
	}

	public int getJulkaisuvuosi() {
		return julkaisuvuosi;
	}

	public void setJulkaisuvuosi(int vuosi) {
		this.julkaisuvuosi = vuosi;
	}

	public String getTeoksenNimi() {
		return teoksenNimi;
	}

	public void setTeoksenNimi(String nimi) {
		this.teoksenNimi = nimi;
	}

	public String getTekija() {
		return tekija;
	}

	public void setTekija(String tekija) {
		this.tekija = tekija;
	}

	public String toString() {
		String tiedot = "--------------------------------\n" + "- Kirjan nimi: " + this.getTeoksenNimi() + "\n"
				+ "- Tekij�: " + this.getTekija() + "\n" + "- Julkaisuvuosi: " + this.getJulkaisuvuosi() + "\n"
				+ "--------------------------------";
		return tiedot;
	}

}
