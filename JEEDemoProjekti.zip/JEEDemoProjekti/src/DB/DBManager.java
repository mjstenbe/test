package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBManager {

	public Connection getConnection() {

		Connection conn = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_demo", "root", "");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;

	}

	public ResultSet runQuery(Connection conn, String SQL) {

		ResultSet rs = null;

		try {
			PreparedStatement query = conn.prepareStatement(SQL);

			rs = query.executeQuery();

		} catch (SQLException e) {
			e.getCause();
			System.out.println("Tapahtui virhe tietojen haussa!");
		}

		return rs;
	}

}
